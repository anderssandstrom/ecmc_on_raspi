/* SPDX-License-Identifier: GPL-2.0 */
#ifndef ARM_PLAT_SCHED_CLOCK_H
#define ARM_PLAT_SCHED_CLOCK_H

void versatile_sched_clock_init(void __iomem *, unsigned long);

#endif
