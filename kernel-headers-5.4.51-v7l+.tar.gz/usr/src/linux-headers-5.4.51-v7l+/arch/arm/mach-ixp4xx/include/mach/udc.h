/*
 * arch/arm/mach-ixp4xx/include/mach/udc.h
 *
 */
#include <linux/platform_data/pxa2xx_udc.h>

extern void ixp4xx_set_udc_info(struct pxa2xx_udc_mach_info *info);

