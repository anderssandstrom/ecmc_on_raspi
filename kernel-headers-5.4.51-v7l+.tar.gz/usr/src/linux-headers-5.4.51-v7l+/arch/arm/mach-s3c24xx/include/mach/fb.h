/* SPDX-License-Identifier: GPL-2.0 */
#include <plat/fb-s3c2410.h>
